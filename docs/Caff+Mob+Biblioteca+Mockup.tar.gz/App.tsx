import React, { useEffect, useRef, useState } from "react";
import { BookOpen, Blocks, Layers, Search, Pin, Minus, X, ChevronDown, LogOut, RefreshCw, Users, UserPlus, Check, Sun, Moon, Sparkles } from "lucide-react";

type Theme = "light" | "dark";
type Category = "Armários" | "Portas" | "Janelas" | "Armários autorais";

const categories: Category[] = ["Armários", "Portas", "Janelas", "Armários autorais"];
const filters = ["Madeira", "Alumínio", "Blindex"];

const models = [
  { name: "Balcão 1 porta", kind: "balcao1", note: "Frente simples, puxador central" },
  { name: "Balcão 2 portas", kind: "balcao2", note: "Frente dupla, puxadores em par" },
  { name: "Aéreo 1 porta", kind: "aereo1", note: "Módulo suspenso compacto" },
  { name: "Aéreo 2 portas", kind: "aereo2", note: "Módulo suspenso duplo" },
  { name: "Torre 1 porta", kind: "torre1", note: "Módulo alto e vertical" },
  { name: "Balcão 3 portas", kind: "balcao3", note: "Frente tripla, puxadores alinhados" },
];

function Drawing({ kind }: { kind: string }) {
  const frame = { fill: "none", stroke: "var(--ink)", strokeWidth: 3, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  const detail = { fill: "none", stroke: "var(--muted)", strokeWidth: 1.8, strokeLinecap: "round" as const };
  const handle = { fill: "none", stroke: "var(--primary)", strokeWidth: 5, strokeLinecap: "round" as const };
  if (kind === "balcao1") return <svg viewBox="0 0 180 140" className="h-full w-full" aria-hidden="true"><rect x="25" y="25" width="130" height="95" rx="4" {...frame}/><line x1="25" y1="42" x2="155" y2="42" {...detail}/><line x1="132" y1="72" x2="132" y2="102" {...handle}/></svg>;
  if (kind === "balcao2") return <svg viewBox="0 0 180 140" className="h-full w-full" aria-hidden="true"><rect x="25" y="25" width="130" height="95" rx="4" {...frame}/><line x1="90" y1="25" x2="90" y2="120" {...detail}/><line x1="78" y1="70" x2="78" y2="100" {...handle}/><line x1="102" y1="70" x2="102" y2="100" {...handle}/></svg>;
  if (kind === "aereo1") return <svg viewBox="0 0 180 140" className="h-full w-full" aria-hidden="true"><rect x="28" y="35" width="124" height="68" rx="4" {...frame}/><line x1="28" y1="47" x2="152" y2="47" {...detail}/><line x1="128" y1="60" x2="128" y2="85" {...handle}/><path d="M48 112h84" {...detail}/></svg>;
  if (kind === "aereo2") return <svg viewBox="0 0 180 140" className="h-full w-full" aria-hidden="true"><rect x="28" y="35" width="124" height="68" rx="4" {...frame}/><line x1="90" y1="35" x2="90" y2="103" {...detail}/><line x1="80" y1="62" x2="80" y2="86" {...handle}/><line x1="100" y1="62" x2="100" y2="86" {...handle}/><path d="M48 112h84" {...detail}/></svg>;
  if (kind === "torre1") return <svg viewBox="0 0 180 140" className="h-full w-full" aria-hidden="true"><rect x="55" y="12" width="70" height="118" rx="4" {...frame}/><line x1="55" y1="30" x2="125" y2="30" {...detail}/><line x1="110" y1="65" x2="110" y2="92" {...handle}/></svg>;
  return <svg viewBox="0 0 180 140" className="h-full w-full" aria-hidden="true"><rect x="20" y="25" width="140" height="95" rx="4" {...frame}/><line x1="67" y1="25" x2="67" y2="120" {...detail}/><line x1="113" y1="25" x2="113" y2="120" {...detail}/><line x1="56" y1="72" x2="56" y2="100" {...handle}/><line x1="124" y1="72" x2="124" y2="100" {...handle}/></svg>;
}

export default function App() {
  const [theme, setTheme] = useState<Theme>("light");
  const [category, setCategory] = useState<Category>("Janelas");
  const [filter, setFilter] = useState("Madeira");
  const [selected, setSelected] = useState("Balcão 1 porta");
  const [accountOpen, setAccountOpen] = useState(false);
  const [signedIn, setSignedIn] = useState(true);
  const [toast, setToast] = useState("");
  const [pinned, setPinned] = useState(false);
  const accountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (e: MouseEvent) => { if (accountRef.current && !accountRef.current.contains(e.target as Node)) setAccountOpen(false); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);
  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(""), 3200);
    return () => window.clearTimeout(t);
  }, [toast]);

  const showToast = (msg: string) => setToast(msg);
  const signOut = () => { setSignedIn(false); setAccountOpen(false); showToast("Você saiu"); };
  const signIn = () => { setSignedIn(true); setAccountOpen(false); showToast("Login simulado"); };

  return (
    <div data-safe-area-inset-root data-theme={theme} className="min-h-screen bg-[var(--page)] text-[var(--ink)] transition-colors" style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" }}>
      <main className="mx-auto w-full max-w-[1500px] px-3 py-5 sm:px-5 sm:py-8 lg:px-8 lg:py-10">
        <header className="mb-5 flex flex-wrap items-end justify-between gap-4 sm:mb-7">
          <div>
            <p className="mb-2 flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.18em] text-[var(--primary)]"><Sparkles size={16} /> CAFF MOB • DRAW</p>
            <h1 className="font-display text-[clamp(2rem,5vw,3.4rem)] leading-[0.95] font-semibold">Biblioteca de <br className="hidden sm:block" /> acabamentos</h1>
          </div>
          <p className="max-w-[420px] text-[15px] leading-6 text-[var(--muted)] [overflow-wrap:anywhere]">Escolha um modelo da biblioteca e substitua o item selecionado no seu projeto. O mockup mantém a estrutura original, com mais respiro e fonte maior.</p>
        </header>

        <section aria-label="Janela Biblioteca do CAFF MOB DRAW" className="overflow-hidden rounded-[24px] border border-[var(--line)] bg-[var(--window)] shadow-[var(--shadow)]">
          {/* Topo da janela */}
          <div className="flex flex-wrap items-center gap-3 border-b border-[var(--line)] px-4 py-4 sm:px-6 sm:py-5">
            <nav aria-label="Seções da biblioteca" className="flex min-w-0 flex-wrap items-center gap-2">
              <button className="min-touch flex items-center gap-2 rounded-full bg-[var(--primary)] px-4 py-2 text-[15px] font-bold text-white shadow-sm"><BookOpen size={19} /> Biblioteca</button>
              <button onClick={() => showToast("Seção Blocos — conteúdo de exemplo")} className="min-touch flex items-center gap-2 rounded-full px-4 py-2 text-[15px] font-semibold text-[var(--muted)] hover:bg-[var(--primary-soft)] hover:text-[var(--ink)]"><Blocks size={19} /> Blocos</button>
              <button onClick={() => showToast("Seção Texturas — conteúdo de exemplo")} className="min-touch flex items-center gap-2 rounded-full px-4 py-2 text-[15px] font-semibold text-[var(--muted)] hover:bg-[var(--primary-soft)] hover:text-[var(--ink)]"><Layers size={19} /> Texturas</button>
            </nav>

            <div className="ml-auto flex w-full flex-wrap items-center justify-end gap-2 sm:w-auto sm:flex-nowrap">
              <label className="relative min-w-[180px] flex-1 sm:w-[280px] sm:flex-none">
                <span className="sr-only">Buscar acabamento</span>
                <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[var(--muted)]" size={19} />
                <input defaultValue="" placeholder="Buscar acabamento..." className="min-touch w-full rounded-full border border-[var(--line)] bg-[var(--card)] py-2 pl-11 pr-4 text-[15px] text-[var(--ink)] placeholder:text-[var(--muted)]" />
              </label>

              <div className="flex items-center rounded-full border border-[var(--line)] bg-[var(--card)] p-1" role="group" aria-label="Alternar tema">
                <button onClick={() => setTheme("light")} aria-pressed={theme === "light"} className={`min-touch flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[13px] font-bold ${theme === "light" ? "bg-[var(--primary)] text-white" : "text-[var(--muted)]"}`}><Sun size={16} /> Light</button>
                <button onClick={() => setTheme("dark")} aria-pressed={theme === "dark"} className={`min-touch flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[13px] font-bold ${theme === "dark" ? "bg-[var(--ink)] text-[var(--page)]" : "text-[var(--muted)]"}`}><Moon size={16} /> Dark</button>
              </div>

              <button onClick={() => { setPinned(!pinned); showToast(pinned ? "Janela desafixada" : "Janela fixada"); }} aria-pressed={pinned} aria-label={pinned ? "Desafixar janela" : "Fixar janela"} title="Fixar janela" className={`min-touch flex h-11 w-11 items-center justify-center rounded-full border ${pinned ? "border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary)]" : "border-[var(--line)] bg-[var(--card)] text-[var(--muted)]"}`}><Pin size={20} className={pinned ? "fill-current" : ""} /></button>

              {/* Avatar ao lado do Pin */}
              <div ref={accountRef} className="relative">
                {signedIn ? (
                  <button onClick={() => setAccountOpen(!accountOpen)} aria-expanded={accountOpen} aria-haspopup="menu" className="min-touch flex items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--card)] py-1 pl-1 pr-2.5 shadow-sm">
                    <span className="relative flex h-10 w-10 items-center justify-center rounded-full bg-[var(--teal)] text-[17px] font-bold text-white" aria-hidden="true">M<span className="absolute -right-0.5 -top-0.5 h-3.5 w-3.5 rounded-full border-2 border-[var(--card)] bg-emerald-500" /></span>
                    <span className="hidden text-left leading-tight md:block"><span className="block max-w-[110px] truncate text-[13px] font-bold">M&E Móveis</span><span className="block text-[11px] text-[var(--muted)]">Conta ativa</span></span>
                    <ChevronDown size={16} className={`text-[var(--muted)] transition-transform ${accountOpen ? "rotate-180" : ""}`} />
                  </button>
                ) : (
                  <button onClick={() => setAccountOpen(!accountOpen)} aria-expanded={accountOpen} aria-haspopup="menu" className="min-touch flex items-center gap-2 rounded-full bg-[var(--teal)] px-4 py-2 text-[15px] font-bold text-white shadow-sm"><span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/20 text-[13px]">M</span> Entrar <ChevronDown size={16} /></button>
                )}
                {accountOpen && (
                  <div role="menu" className="absolute right-0 top-[calc(100%+10px)] z-30 w-[300px] max-w-[calc(100vw-2rem)] overflow-hidden rounded-[18px] border border-[var(--line)] bg-[var(--card)] shadow-[var(--shadow)]">
                    <div className="flex items-center gap-3 border-b border-[var(--line)] bg-[var(--primary-soft)] p-4">
                      <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-[var(--teal)] text-[22px] font-bold text-white">M</span>
                      <div className="min-w-0"><p className="font-bold leading-tight [overflow-wrap:anywhere]">M&E Móveis Planejados</p><p className="mt-1 break-all text-[13px] text-[var(--muted)]">memoveispl@email.com</p></div>
                    </div>
                    <div className="p-2">
                      {signedIn ? <>
                        <button role="menuitem" onClick={() => { setAccountOpen(false); showToast("Escolha outra conta para continuar"); }} className="min-touch flex w-full items-center gap-3 rounded-xl px-3 text-left text-[15px] font-semibold hover:bg-[var(--primary-soft)]"><UserPlus size={19} className="text-[var(--teal)]" /> Entrar com outra conta</button>
                        <button role="menuitem" onClick={() => { setAccountOpen(false); showToast("Troca de conta — exemplo"); }} className="min-touch flex w-full items-center gap-3 rounded-xl px-3 text-left text-[15px] font-semibold hover:bg-[var(--primary-soft)]"><RefreshCw size={19} className="text-[var(--teal)]" /> Trocar de conta</button>
                        <button role="menuitem" onClick={() => { setAccountOpen(false); showToast("Gerenciamento de contas — exemplo"); }} className="min-touch flex w-full items-center gap-3 rounded-xl px-3 text-left text-[15px] font-semibold hover:bg-[var(--primary-soft)]"><Users size={19} className="text-[var(--teal)]" /> Gerenciar contas</button>
                        <div className="my-2 h-px bg-[var(--line)]" />
                        <button role="menuitem" onClick={signOut} className="min-touch flex w-full items-center gap-3 rounded-xl px-3 text-left text-[15px] font-bold text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30"><LogOut size={19} /> Sair</button>
                      </> : <>
                        <button role="menuitem" onClick={signIn} className="min-touch flex w-full items-center gap-3 rounded-xl px-3 text-left text-[15px] font-bold text-[var(--teal)] hover:bg-[var(--primary-soft)]"><UserPlus size={19} /> Entrar</button>
                        <p className="px-3 pb-2 pt-1 text-[13px] leading-5 text-[var(--muted)]">Entre para sincronizar sua biblioteca e continuar de onde parou.</p>
                      </>}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button onClick={() => showToast("Minimizar — exemplo do mockup")} aria-label="Minimizar" className="min-touch flex h-11 w-11 items-center justify-center rounded-full border border-[var(--line)] bg-[var(--card)] text-[var(--muted)]"><Minus size={19} /></button>
                <button onClick={() => showToast("Fechar — exemplo do mockup")} aria-label="Maximizar ou fechar" className="min-touch flex h-11 w-11 items-center justify-center rounded-full border border-[var(--line)] bg-[var(--card)] text-[var(--muted)] hover:border-red-300 hover:text-red-600"><X size={19} /></button>
              </div>
            </div>
          </div>

          {/* Corpo: sidebar + grade */}
          <div className="flex flex-col lg:flex-row">
            <aside className="border-b border-[var(--line)] bg-[var(--sidebar)] p-5 sm:p-6 lg:w-[310px] lg:shrink-0 lg:border-b-0 lg:border-r">
              <div className="flex flex-col gap-6 lg:min-h-[660px]">
                <div>
                  <h2 className="mb-4 text-[12px] font-bold uppercase tracking-[0.16em] text-[var(--muted)]">Categorias</h2>
                  <div className="flex gap-2 overflow-x-auto pb-1 lg:flex-col lg:overflow-visible lg:pb-0">
                    {categories.map((c) => (
                      <button key={c} onClick={() => setCategory(c)} aria-pressed={category === c} className={`min-touch shrink-0 whitespace-nowrap rounded-[14px] px-4 py-3 text-left text-[16px] font-bold transition-colors lg:w-full ${category === c ? "bg-[var(--primary)] text-white shadow-sm" : "bg-[var(--card)] text-[var(--ink)] hover:bg-[var(--primary-soft)]"}`}>{c}</button>
                    ))}
                  </div>
                </div>
                <div className="mt-auto border-t border-[var(--line)] pt-6">
                  <h3 className="mb-4 text-[12px] font-bold uppercase tracking-[0.16em] text-[var(--muted)]">Acabamento</h3>
                  <div className="flex flex-wrap gap-2">
                    {filters.map((f) => <button key={f} onClick={() => setFilter(f)} aria-pressed={filter === f} className={`min-touch rounded-full px-4 py-2 text-[14px] font-bold ${filter === f ? "bg-[var(--primary)] text-white" : "border border-[var(--line)] bg-[var(--card)] text-[var(--muted)]"}`}>{f}</button>)}
                  </div>
                  <button onClick={() => showToast(`“${selected}” pronto para substituir o item selecionado`)} disabled={!selected} className="min-touch mt-5 w-full rounded-[14px] bg-[var(--primary-strong)] px-4 py-3.5 text-[16px] font-bold text-white shadow-sm hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50">Substituir pelo selecionado</button>
                  <p className="mt-3 text-[13px] leading-5 text-[var(--muted)]">Seleção atual: <strong className="text-[var(--ink)]">{selected}</strong> • {filter}</p>
                </div>
              </div>
            </aside>

            <section className="min-w-0 flex-1 p-5 sm:p-7 lg:p-8">
              <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
                <div><h2 className="font-display text-[clamp(1.55rem,3vw,2.25rem)] leading-none font-semibold">{category}</h2><p className="mt-2 text-[15px] text-[var(--muted)]">{category} • 6 modelos • {filter}</p></div>
                <span className="rounded-full border border-[var(--line)] bg-[var(--card)] px-3 py-2 text-[13px] font-bold text-[var(--teal)]">Clique em um card para selecionar</span>
              </div>
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                {models.map((m) => {
                  const active = selected === m.name;
                  return (
                    <article key={m.name} onClick={() => setSelected(m.name)} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setSelected(m.name); } }} tabIndex={0} role="button" aria-pressed={active} className={`group cursor-pointer overflow-hidden rounded-[16px] border bg-[var(--card)] shadow-[var(--shadow-card)] transition-transform hover:-translate-y-0.5 ${active ? "border-[var(--primary)] ring-4 ring-orange-500/15" : "border-[var(--line)]"}`} style={{ borderWidth: active ? 3 : 1 }}>
                      <div className="relative flex h-[190px] items-center justify-center bg-[var(--card-art)] p-6 sm:h-[210px]">
                        <div className="h-full w-full max-w-[230px] text-[var(--ink)]"><Drawing kind={m.kind} /></div>
                        {active && <span className="absolute left-4 top-4 flex items-center gap-1.5 rounded-full bg-[var(--primary)] px-3 py-1.5 text-[12px] font-bold text-white shadow"><Check size={14} /> Selecionado</span>}
                        <span className="absolute bottom-4 right-4 rounded-full bg-[var(--card)] px-2.5 py-1 text-[11px] font-bold text-[var(--muted)]">SVG • escala livre</span>
                      </div>
                      <div className="flex items-start justify-between gap-3 p-5 sm:p-6">
                        <div><h3 className="text-[18px] font-bold leading-snug [overflow-wrap:anywhere]">{m.name}</h3><p className="mt-1 text-[14px] text-[var(--muted)]">Modelo pronto</p><p className="mt-2 text-[13px] leading-5 text-[var(--muted)] [overflow-wrap:anywhere]">{m.note}</p></div>
                        <span className={`mt-1 h-4 w-4 shrink-0 rounded-full border-2 ${active ? "border-[var(--primary)] bg-[var(--primary)]" : "border-[var(--line-strong)]"}`} aria-hidden="true" />
                      </div>
                    </article>
                  );
                })}
              </div>
            </section>
          </div>
        </section>

        <p className="mt-5 text-center text-[14px] leading-6 text-[var(--muted)]">Mockup • Light é o padrão • Dark mantém o preto atual • Clique no avatar ao lado do Pin para ver Logar / Sair</p>
      </main>

      <div aria-live="polite" className="pointer-events-none fixed bottom-5 left-1/2 z-50 -translate-x-1/2 px-3">
        {toast && <div className="max-w-[92vw] rounded-full bg-[var(--ink)] px-5 py-3 text-center text-[15px] font-bold text-[var(--page)] shadow-2xl [overflow-wrap:anywhere]">{toast}</div>}
      </div>
    </div>
  );
}
