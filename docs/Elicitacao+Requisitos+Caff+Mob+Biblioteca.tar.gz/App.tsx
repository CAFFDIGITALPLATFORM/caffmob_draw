import React, { useEffect, useMemo, useState } from "react";
import { BookOpen, CheckCircle2, ChevronDown, CloudOff, Contrast, FileCheck2, Fingerprint, Layers, Monitor, MousePointer2, Palette, Search, SunMoon, Users, AlertTriangle, Database, Smartphone, RefreshCw, Save } from "lucide-react";

type CheckItem = { id: string; group: string; label: string; detail: string };
const CHECK_ITEMS: CheckItem[] = [
  { id: "RF01", group: "Requisitos funcionais", label: "RF01 — Janela Biblioteca com abas", detail: "Biblioteca ativa, Blocos e Texturas visíveis e navegáveis." },
  { id: "RF02", group: "Requisitos funcionais", label: "RF02 — Busca por acabamento", detail: "Placeholder “Buscar acabamento...”, lupa e filtragem em tempo real." },
  { id: "RF03", group: "Requisitos funcionais", label: "RF03 — Categorias da sidebar", detail: "Armários, Portas, Janelas e Armários autorais no lugar da lista anterior." },
  { id: "RF04", group: "Requisitos funcionais", label: "RF04 — Troca de categoria", detail: "Título da grade e destaque acompanham a categoria ativa." },
  { id: "RF05", group: "Requisitos funcionais", label: "RF05 — Grade 2 × 3", detail: "Seis modelos, cada card com desenho, nome e “Modelo pronto”." },
  { id: "RF06", group: "Requisitos funcionais", label: "RF06 — Seleção de card", detail: "Borda laranja + selo “Selecionado”, apenas um por vez." },
  { id: "RF07", group: "Requisitos funcionais", label: "RF07 — Filtros em pílulas", detail: "Madeira ativa por padrão; Alumínio e Blindex como alternativas exclusivas." },
  { id: "RF08", group: "Requisitos funcionais", label: "RF08 — Botão Substituir", detail: "Habilitado só com seleção e confirma a ação antes de concluir." },
  { id: "RF09", group: "Requisitos funcionais", label: "RF09 — Alternância de tema", detail: "Light padrão, Dark instantâneo, sem recarregar e com preferência persistida." },
  { id: "RF10", group: "Requisitos funcionais", label: "RF10 — Avatar ao lado do Pin", detail: "Avatar visível, ponto online e seta; toque/clique abre o dropdown." },
  { id: "RF11", group: "Requisitos funcionais", label: "RF11 — Dropdown de conta", detail: "Nome, e-mail, Entrar com outra conta, Trocar, Gerenciar e Sair em vermelho." },
  { id: "RF12", group: "Requisitos funcionais", label: "RF12 — Controles de janela", detail: "Pin, Minimizar, Maximizar e Fechar com comportamento visual claro." },
  { id: "RF13", group: "Requisitos funcionais", label: "RF13 — Mouse + touch", detail: "Alvos mínimos de 44 px em controles interativos." },
  { id: "RF14", group: "Requisitos funcionais", label: "RF14 — Layout responsivo", detail: "Em tela estreita, a sidebar vira linha horizontal acima da grade." },
  { id: "TEST-TEMA", group: "Testes de experiência", label: "Teste de tema", detail: "Alternar Light/Dark várias vezes, sem perda de seleção ou rolagem." },
  { id: "TEST-AVATAR", group: "Testes de experiência", label: "Teste de avatar e conta", detail: "Abrir, fechar, trocar conta e validar o estado “Entrar” após Sair." },
  { id: "TEST-TOUCH", group: "Testes de experiência", label: "Teste touch", detail: "Tocar com o dedo em categoria, filtro, card, tema e avatar." },
  { id: "TEST-MOUSE", group: "Testes de experiência", label: "Teste mouse", detail: "Clicar, passar o cursor, usar foco por teclado e atalhos esperados." },
  { id: "TEST-RESPONSIVO", group: "Testes de experiência", label: "Teste responsivo", detail: "Validar 1366×768, 1920×1080 e larguras móveis sem corte ou sobreposição." },
  { id: "TEST-CONTRASTE", group: "Testes de experiência", label: "Teste de contraste", detail: "Conferir WCAG AA em texto, bordas, selos e estados desabilitados." },
  { id: "TEST-PERFORMANCE", group: "Testes de experiência", label: "Teste de performance", detail: "Abertura abaixo de 1 s e troca de tema abaixo de 100 ms." },
];

const TOC = [
  ["1", "Objetivo e visão"], ["2", "Escopo"], ["3", "Stakeholders e personas"], ["4", "Requisitos funcionais"],
  ["5", "Regras de negócio"], ["6", "Requisitos não funcionais"], ["7", "Interface / Design System"],
  ["8", "Requisitos de máquinas"], ["9", "Software / compatibilidade"], ["10", "Histórias de usuário"],
  ["11", "Casos de uso"], ["12", "Critérios de aceite e checklist"], ["13", "Matriz de rastreabilidade"],
  ["14", "Glossário"], ["15", "Riscos e premissas"],
] as const;

async function api(action: string, args: Record<string, unknown>) {
  const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, args }) });
  const payload = await res.json().catch(() => ({}));
  if (!res.ok || payload?.error) throw new Error(payload?.error || `Falha na operação (${res.status})`);
  return payload.data;
}

function Section({ id, kicker, title, children }: { id: string; kicker: string; title: string; children: React.ReactNode }) {
  return <section id={id} className="py-10 sm:py-12 border-t border-[var(--border)]">
    <p className="text-xs font-extrabold uppercase tracking-[0.22em] text-[var(--primary)]">{kicker}</p>
    <h2 className="mt-3 text-3xl sm:text-[2.55rem] font-black leading-[1.08] [overflow-wrap:anywhere]">{title}</h2>
    <div className="mt-6 space-y-5 text-[1.02rem] leading-8 text-[var(--ink)]">{children}</div>
  </section>;
}
function Callout({ icon, title, children, tone = "orange" }: { icon: React.ReactNode; title: string; children: React.ReactNode; tone?: "orange" | "teal" }) {
  return <div className="rounded-2xl border border-[var(--border)] p-5 sm:p-6 flex gap-4" style={{ background: tone === "orange" ? "var(--primary-soft)" : "var(--teal-soft)" }}>
    <div className="shrink-0 text-[var(--primary)]">{icon}</div><div><p className="font-bold text-lg leading-snug">{title}</p><div className="mt-2 text-[0.98rem] leading-7">{children}</div></div>
  </div>;
}
function Table({ head, rows }: { head: string[]; rows: React.ReactNode[][] }) {
  return <div className="table-wrap"><table><thead><tr>{head.map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody></table></div>;
}
function Pill({ children, active = false }: { children: React.ReactNode; active?: boolean }) { return <span className="inline-flex min-h-[34px] items-center rounded-full border px-3 py-1 text-sm font-bold" style={{ background: active ? "var(--primary)" : "var(--card)", color: active ? "#fff" : "var(--ink)", borderColor: active ? "var(--primary)" : "var(--border)" }}>{children}</span>; }

export default function App() {
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [checks, setChecks] = useState<Record<string, boolean>>({});
  const [recordIds, setRecordIds] = useState<Record<string, string>>({});
  const [savingId, setSavingId] = useState<string | null>(null);
  const [status, setStatus] = useState<string>("Carregando o progresso salvo…");
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const data = await api("records.list", { collection: "caff-mob-checklist" }) as { records: { id: string; value: { itemId?: string; checked?: boolean } }[] };
        if (!alive) return;
        const next: Record<string, boolean> = {}; const ids: Record<string, string> = {};
        for (const r of data?.records || []) if (r.value?.itemId) { next[r.value.itemId] = !!r.value.checked; ids[r.value.itemId] = r.id; }
        setChecks(next); setStatus(Object.keys(next).length ? "Progresso salvo carregado." : "Nenhum item marcado ainda.");
      } catch { if (alive) setStatus("Serviço de salvamento indisponível no momento. As marcações ficam apenas nesta visualização."); }
    })();
    return () => { alive = false; };
  }, []);

  const done = useMemo(() => CHECK_ITEMS.filter(i => checks[i.id]).length, [checks]);
  const progress = Math.round(done / CHECK_ITEMS.length * 100);

  async function toggleCheck(item: CheckItem) {
    const nextValue = !checks[item.id];
    setChecks(prev => ({ ...prev, [item.id]: nextValue }));
    setSavingId(item.id); setStatus("Salvando marcação…");
    try {
      const existing = recordIds[item.id];
      if (existing) await api("records.replace", { collection: "caff-mob-checklist", id: existing, value: { itemId: item.id, checked: nextValue } });
      else {
        const created = await api("records.create", { collection: "caff-mob-checklist", value: { itemId: item.id, checked: nextValue }, idempotency_key: `caff-check-${item.id}-${Date.now()}` }) as { id: string };
        setRecordIds(prev => ({ ...prev, [item.id]: created.id }));
      }
      setStatus(`“${item.label}” salvo.`);
    } catch (e) { setStatus(`Não foi possível salvar “${item.label}”. A marcação ficou apenas nesta visualização. Erro: ${e instanceof Error ? e.message : String(e)}`); }
    setSavingId(null);
  }
  async function toggleTheme() {
    const next = theme === "light" ? "dark" : "light"; setTheme(next);
    try { await api("records.create", { collection: "caff-mob-doc-preferences", value: { theme: next, updatedAt: new Date().toISOString() }, idempotency_key: `caff-theme-${next}-${Date.now()}` }); setStatus(`Tema ${next === "dark" ? "Dark" : "Light"} aplicado.`); } catch { setStatus("Tema aplicado nesta visualização; o salvamento da preferência está indisponível."); }
  }

  const shellStyle: React.CSSProperties = { boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" };
  return <div data-safe-area-inset-root data-theme={theme} className="min-h-screen bg-[var(--page)] text-[var(--ink)] overflow-x-clip" style={shellStyle}>
    <div className="mx-auto max-w-[1180px] px-4 sm:px-6 lg:px-8 pb-16">
      {/* Header */}
      <header className="pt-6 sm:pt-9">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--primary)] text-white"><BookOpen size={22} /></span><div><p className="font-black tracking-[0.18em] text-sm">CAFF MOB DRAW</p><p className="text-sm text-[var(--muted)]">Biblioteca · Documento de requisitos</p></div></div>
          <div className="flex items-center gap-2">
            <span className="rounded-full border border-[var(--border)] bg-[var(--card)] px-3 py-2 text-sm font-bold">Versão 1.0</span>
            <button onClick={toggleTheme} className="min-h-[44px] inline-flex items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--card)] px-4 font-bold hover:border-[var(--primary)]"><SunMoon size={18} /> {theme === "light" ? "Ver em Dark" : "Ver em Light"}</button>
          </div>
        </div>
        <div className="mt-8 grid gap-8 lg:grid-cols-[1.55fr_.75fr] items-end">
          <div><p className="text-sm font-extrabold uppercase tracking-[0.22em] text-[var(--teal)]">Elicitação de Requisitos · Agnóstico de tecnologia</p><h1 className="mt-4 text-[clamp(2.4rem,6vw,4.4rem)] font-black leading-[0.98] [overflow-wrap:anywhere]">Recriar a janela Biblioteca sem perder o que já funciona.</h1><p className="mt-5 max-w-[760px] text-lg leading-8 text-[var(--muted)]">Este documento descreve <strong className="text-[var(--ink)]">o que</strong> o mockup deve fazer em qualquer linguagem — HTML/CSS/JS, Flutter, C#, Delphi, Python/Qt ou React. A estrutura atual não muda; o tema, a leitura e o toque ficam melhores.</p></div>
          <div className="rounded-3xl border border-[var(--border)] bg-[var(--card)] p-5 shadow-[var(--shadow)]"><p className="text-xs uppercase tracking-[0.18em] font-bold text-[var(--muted)]">Ficha do documento</p><dl className="mt-4 space-y-3 text-[0.98rem]"><div className="flex justify-between gap-3"><dt>Data</dt><dd className="font-bold">26/11/2026</dd></div><div className="flex justify-between gap-3"><dt>Autor</dt><dd className="font-bold">CAFF MOB</dd></div><div className="flex justify-between gap-3"><dt>Tema padrão</dt><dd className="font-bold">Light</dd></div><div className="flex justify-between gap-3"><dt>Escopo</dt><dd className="font-bold text-right">Janela Biblioteca</dd></div></dl></div>
        </div>
        <div className="mt-7 grid gap-3 sm:grid-cols-3">
          <Callout icon={<Layers size={24} />} title="Mesma estrutura"><p>Não reinventar a janela. Melhorar leitura, tema, toque e estados.</p></Callout>
          <Callout icon={<Palette size={24} />} title="Cores CAFF MOB" tone="teal"><p>Creme, marrom, laranja e teal aplicados com hierarquia consistente.</p></Callout>
          <Callout icon={<MousePointer2 size={24} />} title="Mouse + touch" tone="teal"><p>Os mesmos controles devem funcionar bem no balcão e no projetista.</p></Callout>
        </div>
      </header>

      {/* TOC */}
      <nav aria-label="Índice do documento" className="mt-10 rounded-3xl border border-[var(--border)] bg-[var(--window)] p-5 sm:p-7">
        <div className="flex items-center justify-between gap-4"><h2 className="text-2xl font-black">Índice</h2><span className="text-sm text-[var(--muted)]">15 seções · use as âncoras para revisar</span></div>
        <ol className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{TOC.map(([n, label]) => <li key={n}><a href={`#s${n}`} className="flex min-h-[44px] items-center gap-3 rounded-xl px-3 py-2 font-semibold hover:bg-[var(--primary-soft)]"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[var(--primary)] text-white text-sm font-black">{n}</span><span className="[overflow-wrap:anywhere]">{label}</span></a></li>)}</ol>
        <p className="mt-5 text-sm text-[var(--muted)]">Como ler: cada requisito tem um ID estável. Use esse ID em tarefas, revisões, testes e na matriz da seção 13.</p>
      </nav>

      <Section id="s1" kicker="01 · Objetivo" title="Objetivo e visão">
        <p>Recriar a janela <strong>Biblioteca</strong> do CAFF MOB DRAW sem mudar a estrutura atual, com tema <strong>Light como padrão</strong> e tema <strong>Dark</strong> equivalente, cores CAFF MOB, leitura confortável e uso fluente com <strong>mouse e touch screen</strong>.</p>
        <Callout icon={<CheckCircle2 size={24} />} title="Visão em uma frase"><p>A mesma janela, mais legível, mais previsível e mais confortável em loja clara, loja escura, desktop com mouse e balcão com tela sensível ao toque.</p></Callout>
        <ul className="list-disc pl-6 space-y-2"><li>Preservar o modelo mental atual: quem já usa a janela deve reconhecer cada área.</li><li>Separar decisão visual de decisão técnica: o documento vale para qualquer linguagem.</li><li>Tratar o mockup como referência de comportamento, não apenas como imagem.</li></ul>
      </Section>

      <Section id="s2" kicker="02 · Escopo" title="Escopo: o que entra e o que fica fora">
        <Table head={["Âmbito", "Inclui"]} rows={[
          [<strong>Dentro do escopo</strong>, "Janela Biblioteca, abas, busca, sidebar, grade, filtros, avatar/contas, troca de tema e botão Substituir."],
          [<strong>Fora do escopo</strong>, "Cadastro de produtos, edição 3D, backend, banco de dados. Dados simulados / mock."],
        ]} />
        <p><strong>Regra de interpretação:</strong> se uma funcionalidade não está na seção 4, ela não pode ser assumida como obrigatória. Se estiver fora do escopo, não deve bloquear a entrega do mockup.</p>
      </Section>

      <Section id="s3" kicker="03 · Pessoas" title="Stakeholders e personas">
        <div className="grid gap-4 md:grid-cols-2">
          {[
            ["Projetista de móveis planejados", "Monta composições com rapidez, alterna modelos e compara acabamentos. Precisa de leitura imediata e seleção sem erro.", <Users key="a" size={24} />],
            ["Vendedor em loja com touch screen", "Atende o cliente em pé, toca na tela e mostra opções. Precisa de alvos grandes e feedback instantâneo.", <Smartphone key="b" size={24} />],
            ["Operador com mouse", "Trabalha no desktop, usa clique preciso e teclado. Precisa de foco visível e ordem lógica de navegação.", <MousePointer2 key="c" size={24} />],
            ["Administrador", "Garante padrão visual, contas e comportamento da janela. Precisa de regras claras para validar a entrega.", <FileCheck2 key="d" size={24} />],
          ].map(([title, desc, icon]) => <article key={title as string} className="rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5"><div className="text-[var(--primary)]">{icon}</div><h3 className="mt-3 text-xl font-bold">{title}</h3><p className="mt-2 text-[var(--muted)]">{desc}</p></article>)}
        </div>
      </Section>

      <Section id="s4" kicker="04 · Requisitos funcionais" title="Requisitos funcionais — MoSCoW">
        <p><strong>Prioridades:</strong> <Pill active>Must</Pill> obrigatório · <Pill>Should</Pill> importante · <Pill>Could</Pill> desejável. A entrega mínima deve cobrir todos os itens Must.</p>
        <Table head={["ID", "Nome", "Descrição", "Prioridade"]} rows={[
          ["RF01", "Exibir janela Biblioteca", "Abas Biblioteca (ativa), Blocos e Texturas.", <Pill active key="1">Must</Pill>],
          ["RF02", "Busca por acabamento", "Placeholder “Buscar acabamento...”, ícone lupa, filtragem em tempo real.", <Pill active key="2">Must</Pill>],
          ["RF03", "Categorias na sidebar", "Armários, Portas, Janelas e Armários autorais — substituindo Cozinha / Banheiro / Sala / Home office.", <Pill active key="3">Must</Pill>],
          ["RF04", "Trocar categoria ativa", "Clique atualiza o título da grade e o destaque visual.", <Pill active key="4">Must</Pill>],
          ["RF05", "Grade de modelos", "2 colunas × 3 linhas: Balcão 1 porta, Balcão 2 portas, Aéreo 1 porta, Aéreo 2 portas, Torre 1 porta, Balcão 3 portas. Cada card tem desenho, nome e “Modelo pronto”.", <Pill active key="5">Must</Pill>],
          ["RF06", "Selecionar card", "Clique aplica borda laranja + selo “Selecionado”. Apenas um por vez.", <Pill active key="6">Must</Pill>],
          ["RF07", "Filtros em pílulas", "Madeira ativa por padrão; Alumínio e Blindex. Apenas um ativo.", <Pill active key="7">Must</Pill>],
          ["RF08", "Substituir pelo selecionado", "Botão habilitado só com seleção. Ao clicar, confirma a ação.", <Pill active key="8">Must</Pill>],
          ["RF09", "Alternância de tema", "Light padrão ao abrir / Dark. Troca instantânea, sem recarregar, com preferência persistida.", <Pill active key="9">Must</Pill>],
          ["RF10", "Avatar ao lado do Pin", "Avatar visível, ponto online e seta. Toque/clique abre o dropdown.", <Pill active key="10">Must</Pill>],
          ["RF11", "Dropdown de conta", "Cabeçalho com M&E Móveis Planejados + e-mail. Itens: Entrar com outra conta, Trocar de conta, Gerenciar contas e Sair em vermelho.", <Pill active key="11">Must</Pill>],
          ["RF12", "Controles de janela", "Pin (fixar), Minimizar, Maximizar e Fechar (X), com comportamento visual.", <Pill key="12">Should</Pill>],
          ["RF13", "Mouse + touch", "Suporte simultâneo, alvos mínimos de 44 px.", <Pill active key="13">Must</Pill>],
          ["RF14", "Layout responsivo", "Em tela estreita, a sidebar vira linha horizontal acima da grade.", <Pill key="14">Should</Pill>],
        ]} />
      </Section>

      <Section id="s5" kicker="05 · Regras" title="Regras de negócio">
        <Table head={["ID", "Regra", "Efeito esperado"]} rows={[
          ["RN01", "Light é o tema padrão.", "Ao abrir, a janela começa em Light, mesmo sem preferência salva."],
          ["RN02", "Dark preserva o preto atual.", "O Dark não cria um novo layout; preserva a aparência escura já conhecida."],
          ["RN03", "A estrutura não pode ser alterada.", "Áreas, ordem e hierarquia atuais devem ser mantidas."],
          ["RN04", "Seleção única por grupo.", "Apenas uma categoria, um filtro e um card selecionado por vez."],
          ["RN05", "Sair troca o avatar para “Entrar”.", "Após Sair, a conta ativa é removida da exibição e o acesso passa a ser feito por Entrar."],
        ]} />
      </Section>

      <Section id="s6" kicker="06 · Qualidade" title="Requisitos não funcionais">
        <Table head={["ID", "Categoria", "Requisito mensurável"]} rows={[
          ["RNF01", "Usabilidade", "Fonte grande, sem compactação, padding de 20–24 px nas áreas principais."],
          ["RNF02", "Acessibilidade", "Contraste WCAG AA e foco visível em todos os controles interativos."],
          ["RNF03", "Performance", "Abertura abaixo de 1 s; troca de tema abaixo de 100 ms."],
          ["RNF04", "Responsividade", "Adaptação sem corte, sobreposição ou rolagem horizontal indevida."],
          ["RNF05", "Manutenibilidade", "Código legível, organizado e sem minificação no mockup."],
          ["RNF06", "Portabilidade", "Mesmo comportamento em qualquer linguagem que atenda aos requisitos."],
          ["RNF07", "Testabilidade", "Cada RF pode ser validado isoladamente pelo checklist da seção 12."],
          ["RNF08", "Segurança", "Não expor credenciais, tokens ou dados sensíveis na interface."],
          ["RNF09", "Confiabilidade", "Estados previsíveis: seleção, tema, conta e botão Substituir nunca divergem."],
          ["RNF10", "Clareza visual", "Hierarquia consistente de título, subtítulo, selo, botão e texto de apoio."],
        ]} />
      </Section>

      <Section id="s7" kicker="07 · Design System" title="Interface / Design System">
        <p>As cores abaixo são exatas para o mockup. Não aproximar, não substituir por tons “parecidos”.</p>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[
          ["Fundo creme", "#FDF6EC", "#FDF6EC"], ["Marrom", "#2B1A0E", "#2B1A0E"], ["Laranja primário", "#B45309", "#B45309"], ["Teal", "#0E7C74", "#0E7C74"],
        ].map(([n, hex, bg]) => <div key={hex} className="overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--card)]"><div className="h-24" style={{ background: bg }} /><div className="p-4"><p className="font-bold">{n}</p><p className="text-sm text-[var(--muted)]">{hex}</p></div></div>)}</div>
        <h3 className="text-2xl font-bold">Tabela de cores Light</h3>
        <Table head={["Elemento", "Cor"]} rows={[["Fundo da página", "#FDF6EC"], ["Janela", "#FFFBF5"], ["Card", "#FFFFFF"], ["Borda", "#EADDCB"], ["Texto", "#2B1A0E"], ["Texto secundário", "#7A6A5A"], ["Primário", "#B45309"], ["Teal", "#0E7C74"]]} />
        <h3 className="text-2xl font-bold">Tabela de cores Dark</h3>
        <Table head={["Elemento", "Cor"]} rows={[["Página", "#0F0F0F"], ["Janela", "#1A1A1A"], ["Sidebar", "#171717"], ["Card", "#242424"], ["Borda", "#333333"], ["Texto", "#F5F0E8"], ["Texto secundário", "#A8A29E"], ["Primário", "#D97706"], ["Teal", "#2DD4BF"]]} />
        <h3 className="text-2xl font-bold">Forma, tipo e estados</h3>
        <ul className="list-disc pl-6 space-y-2"><li><strong>Cantos:</strong> 16 px nos cards, janelas e painéis principais.</li><li><strong>Sombras:</strong> suaves, apenas para elevar a janela e o dropdown — nunca para “sujar” o fundo.</li><li><strong>Tipografia:</strong> títulos com hierarquia clara; texto corrido grande e espaçado.</li><li><strong>Estados:</strong> normal, hover, ativo, selecionado e desabilitado devem ser distinguíveis sem depender só da cor.</li><li><strong>Botão Substituir:</strong> desabilitado sem seleção; habilitado com seleção; confirmação antes de concluir.</li></ul>
      </Section>

      <Section id="s8" kicker="08 · Máquinas" title="Requisitos de máquinas">
        <Callout icon={<Monitor size={24} />} title="Por que esta seção é detalhada"><p>O mockup precisa funcionar no balcão da loja e no computador do projetista. Por isso, o documento fixa mínimos, recomendados, periféricos e rede — sem amarrar a solução a uma linguagem.</p></Callout>
        <h3 className="text-2xl font-bold">A) Máquina do usuário final — loja / projetista</h3>
        <Table head={["Item", "Mínimo", "Recomendado"]} rows={[
          ["CPU", "Intel Core i3 ou Ryzen 3", "Intel Core i5 ou Ryzen 5"],
          ["RAM", "4 GB", "8 GB ou mais"],
          ["Armazenamento", "500 MB livres", "SSD com 2 GB livres"],
          ["GPU", "Integrada", "Dedicada com 2 GB"],
          ["Tela", "1366 × 768", "1920 × 1080 ou maior"],
          ["Touch screen", "Opcional", "Capacitiva, 10 pontos"],
          ["Entrada", "Mouse + teclado", "Mouse + teclado + touch"],
          ["Rede", "Offline para o mockup", "Online para login / conta"],
          ["Sistema operacional", "Windows 10+", "Windows 10+, macOS ou Linux"],
        ]} />
        <h3 className="text-2xl font-bold">B) Máquina de desenvolvimento</h3>
        <Table head={["Item", "Mínimo", "Recomendado"]} rows={[
          ["CPU", "Intel Core i5 / Ryzen 5", "Intel Core i5 / Ryzen 5 ou superior"],
          ["RAM", "8 GB", "16 GB"],
          ["Armazenamento", "SSD 256 GB", "SSD 256 GB ou maior"],
          ["Tela", "Full HD", "Full HD ou maior"],
          ["Software", "SO + IDE / editor de escolha", "SO + IDE / editor + navegador atualizado"],
          ["Teste", "Navegador atualizado", "Navegador atualizado + emulador touch"],
        ]} />
        <h3 className="text-2xl font-bold">C) Servidor / hospedagem (se houver)</h3>
        <Table head={["Item", "Requisito"]} rows={[
          ["Hospedagem", "Estática, quando o mockup for entregue como página."],
          ["Segurança", "HTTPS quando houver acesso remoto ou login."],
          ["Recursos", "1 vCPU, 512 MB de RAM e 1 GB de disco."],
          ["Operação", "Backup da entrega e registro da versão publicada."],
          ["Exceção", "Se for app desktop sem servidor, esta subseção é dispensada."],
        ]} />
        <h3 className="text-2xl font-bold">Periféricos</h3>
        <ul className="list-disc pl-6 space-y-2"><li><strong>Monitor touch em loja:</strong> 21" ou maior, recomendado.</li><li><strong>Resolução mínima:</strong> 1366 × 768, sem corte de conteúdo.</li><li><strong>Calibração touch:</strong> calibrar antes do uso; validar toque nas bordas e nos cantos.</li><li><strong>Ergonomia:</strong> tela ao alcance do braço, sem reflexo direto sobre os controles.</li></ul>
        <h3 className="text-2xl font-bold">Rede / latência</h3>
        <ul className="list-disc pl-6 space-y-2"><li>O mockup funciona offline, porque os dados são simulados.</li><li>Login e troca de conta exigem rede; a interface deve indicar falha de rede sem travar.</li><li>A troca de tema, a seleção e os filtros são locais e não podem depender da rede.</li></ul>
      </Section>

      <Section id="s9" kicker="09 · Compatibilidade" title="Software / compatibilidade agnóstica">
        <Table head={["Requisito", "Critério"]} rows={[
          ["Linguagem", "Qualquer linguagem é permitida, desde que atenda a este documento."],
          ["Plataforma", "Rodar em Windows, macOS, Linux ou Web."],
          ["Navegadores", "Chrome, Edge, Firefox e Safari atualizados."],
          ["Dependências", "Não depender de biblioteca paga."],
          ["Código", "Fonte legível, sem compactação no mockup."],
          ["Estrutura", "Separar visão, lógica e dados mock."],
        ]} />
      </Section>

      <Section id="s10" kicker="10 · Histórias" title="Histórias de usuário">
        <div className="space-y-4">{[
          ["Como projetista, eu quero alternar Light/Dark para trabalhar em loja clara ou escura.", "Critério de aceite: a troca é instantânea, sem recarregar, e a seleção atual permanece."],
          ["Como projetista, eu quero buscar por acabamento para encontrar o modelo certo sem percorrer toda a grade.", "Critério de aceite: ao digitar, a grade filtra em tempo real; sem resultado, exibe estado vazio claro."],
          ["Como vendedor, eu quero tocar em um card para selecioná-lo para mostrar uma opção ao cliente.", "Critério de aceite: toque aplica borda laranja + selo “Selecionado” e habilita Substituir."],
          ["Como vendedor, eu quero filtrar por Madeira, Alumínio ou Blindex para comparar materiais.", "Critério de aceite: apenas um filtro fica ativo e a grade reflete o filtro escolhido."],
          ["Como operador, eu quero trocar de conta para atender outro usuário no mesmo equipamento.", "Critério de aceite: o dropdown mostra conta atual, opções de troca e confirmação quando exigida."],
          ["Como administrador, eu quero validar a janela em telas diferentes para aprovar a entrega.", "Critério de aceite: o layout se adapta sem corte, com sidebar horizontal em tela estreita."],
        ].map(([story, ac], i) => <article key={i} className="rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5"><p className="text-xs font-bold uppercase tracking-[0.16em] text-[var(--primary)]">HU0{i + 1}</p><p className="mt-2 text-lg font-bold leading-7">{story}</p><p className="mt-2 text-[var(--muted)]">{ac}</p></article>)}</div>
      </Section>

      <Section id="s11" kicker="11 · Casos de uso" title="Casos de uso">
        <Table head={["ID / Caso", "Ator", "Pré-condição", "Fluxo principal", "Alternativo", "Pós-condição"]} rows={[
          ["UC01 · Trocar tema", "Qualquer usuário", "Janela aberta.", "Abrir controle de tema → escolher Light/Dark → interface atualiza.", "Preferência salva falha → tema vale na sessão e o sistema informa.", "Tema aplicado e preferência registrada."],
          ["UC02 · Selecionar modelo", "Projetista / vendedor", "Grade visível.", "Clicar/tocar em um card → aplicar selo e borda.", "Clicar em outro card → a seleção migra para o novo card.", "Um único modelo selecionado."],
          ["UC03 · Trocar conta", "Operador", "Usuário autenticado.", "Abrir avatar → escolher Trocar de conta → confirmar conta.", "Cancelar → mantém a conta atual.", "Conta ativa atualizada."],
          ["UC04 · Sair", "Operador", "Usuário autenticado.", "Abrir avatar → Sair → confirmar.", "Cancelar → mantém a conta atual.", "Avatar passa para o estado “Entrar”."],
          ["UC05 · Filtrar por material", "Projetista / vendedor", "Grade visível.", "Escolher Madeira, Alumínio ou Blindex.", "Filtro sem item → exibir estado vazio.", "Grade filtrada e filtro ativo visível."],
          ["UC06 · Substituir modelo", "Projetista", "Modelo selecionado.", "Clicar em “Substituir pelo selecionado” → confirmar.", "Sem seleção → botão permanece desabilitado.", "Ação confirmada e seleção preservada para revisão."],
        ]} />
      </Section>

      <Section id="s12" kicker="12 · Aceite" title="Critérios de aceite e checklist de testes">
        <p>Marque cada item após validar. O progresso é salvo automaticamente e pode ser retomado depois. A barra abaixo mostra a cobertura da validação.</p>
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5"><div className="flex flex-wrap items-center justify-between gap-3"><p className="font-bold text-lg">Progresso da validação</p><p className="font-black text-2xl text-[var(--primary)]">{done} / {CHECK_ITEMS.length} · {progress}%</p></div><div className="mt-3 h-3 overflow-hidden rounded-full bg-[var(--border)]"><div className="h-full rounded-full bg-[var(--primary)] transition-all" style={{ width: `${progress}%` }} /></div><p className="mt-3 flex items-center gap-2 text-sm text-[var(--muted)]"><Save size={16} /> <span>{status}</span></p></div>
        <div className="grid gap-3 md:grid-cols-2">{CHECK_ITEMS.map(item => <label key={item.id} className="check-row flex cursor-pointer items-start gap-3 rounded-2xl border border-[var(--border)] bg-[var(--card)] p-4"><input type="checkbox" checked={!!checks[item.id]} onChange={() => toggleCheck(item)} disabled={savingId === item.id} className="mt-1 h-6 w-6 shrink-0 accent-[#B45309]" /><span><span className="block font-bold leading-6 [overflow-wrap:anywhere]">{item.label} {savingId === item.id && <span className="text-sm font-normal text-[var(--muted)]">· salvando…</span>}</span><span className="mt-1 block text-sm leading-6 text-[var(--muted)]">{item.detail}</span></span></label>)}</div>
        <Callout icon={<Contrast size={24} />} title="Como registrar um defeito"><p>Se um item falhar, desmarque-o, anote o ID (ex.: RF06), o tema, o dispositivo e o passo que reproduz o problema. Não marque como concluído um item com comportamento parcial.</p></Callout>
        <button onClick={() => setShowAll(v => !v)} className="inline-flex min-h-[44px] items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--card)] px-4 font-bold"> {showAll ? "Ocultar resumo de testes" : "Ver resumo de testes"} <ChevronDown size={18} className={showAll ? "rotate-180" : ""} /></button>
        {showAll && <div className="rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5"><p className="font-bold">Resumo</p><p className="mt-2 text-[var(--muted)]">Testes funcionais: RF01–RF14. Testes de experiência: tema, avatar, touch, mouse, responsivo, contraste e performance. A entrega só é considerada pronta quando todos os itens Must estiverem validados.</p></div>}
      </Section>

      <Section id="s13" kicker="13 · Rastreabilidade" title="Matriz de rastreabilidade">
        <Table head={["RF", "História", "Caso de uso", "Teste"]} rows={[
          ["RF01", "HU06", "—", "Checklist RF01"], ["RF02", "HU02", "—", "Checklist RF02"], ["RF03 / RF04", "HU06", "—", "Checklist RF03 / RF04"],
          ["RF05 / RF06", "HU03", "UC02", "Checklist RF05 / RF06"], ["RF07", "HU04", "UC05", "Checklist RF07"], ["RF08", "HU03", "UC06", "Checklist RF08"],
          ["RF09", "HU01", "UC01", "Checklist RF09 + teste de tema"], ["RF10 / RF11", "HU05", "UC03 / UC04", "Checklist RF10 / RF11 + teste de avatar"],
          ["RF12", "HU06", "—", "Checklist RF12"], ["RF13", "HU03", "UC02", "Testes touch + mouse"], ["RF14", "HU06", "—", "Teste responsivo"],
        ]} />
      </Section>

      <Section id="s14" kicker="14 · Glossário" title="Glossário">
        <Table head={["Termo", "Significado neste documento"]} rows={[
          ["Biblioteca", "Janela que organiza modelos prontos para seleção e substituição."],
          ["Bloco", "Elemento reutilizável da composição, acessível pela aba Blocos."],
          ["Textura", "Aparência superficial aplicada a um modelo, acessível pela aba Texturas."],
          ["Acabamento", "Material e aspecto final pesquisado na busca (ex.: Madeira, Alumínio, Blindex)."],
          ["Armário autoral", "Modelo com desenho próprio, listado como categoria na sidebar."],
          ["Pin", "Controle que fixa a janela no lugar."],
          ["Modelo pronto", "Modelo já configurado, pronto para selecionar e substituir."],
          ["Mock / simulado", "Dado de demonstração, sem backend ou banco de dados real."],
        ]} />
      </Section>

      <Section id="s15" kicker="15 · Riscos" title="Riscos e premissas">
        <div className="grid gap-4 md:grid-cols-2">{[
          ["Touch sem calibração", "Toques errados, seleção imprecisa e frustração no balcão. Mitigar com calibração e validação nas bordas."],
          ["Cores fora do padrão", "Perda de identidade e contraste. Mitigar com a tabela exata da seção 7."],
          ["Estrutura alterada sem necessidade", "Usuário atual se perde. Mitigar com revisão comparativa com a janela atual."],
          ["Dados mock confundidos com dados reais", "Decisão errada em loja. Mitigar com rótulo claro de mock no ambiente de demonstração."],
          ["Tela pequena sem teste", "Conteúdo cortado. Mitigar com o teste responsivo da seção 12."],
          ["Conta trocada sem confirmação", "Ação irreversível por engano. Mitigar com confirmação em Sair e em Trocar de conta."],
        ].map(([t, d]) => <article key={t} className="rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5"><div className="flex items-center gap-2 text-[var(--primary)]"><AlertTriangle size={20} /><h3 className="font-bold text-lg">{t}</h3></div><p className="mt-2 text-[var(--muted)]">{d}</p></article>)}</div>
        <Callout icon={<CloudOff size={24} />} title="Premissa central"><p>Este documento é a fonte da verdade para o mockup. Se uma implementação divergir, a divergência deve ser registrada como decisão explícita — nunca como interpretação silenciosa.</p></Callout>
      </Section>

      <footer className="mt-6 rounded-3xl bg-[var(--ink)] px-5 py-8 text-center text-[var(--page)] sm:px-8"><p className="text-xs font-bold uppercase tracking-[0.22em] opacity-70">CAFF MOB DRAW · Biblioteca · v1.0 · 26/11/2026</p><p className="mx-auto mt-4 max-w-[820px] text-xl sm:text-2xl font-bold leading-8 [overflow-wrap:anywhere]">Documento agnóstico - pode ser implementado em qualquer linguagem que atenda aos requisitos acima.</p><p className="mt-4 flex flex-wrap justify-center gap-2 text-sm opacity-80"><span className="rounded-full border border-white/25 px-3 py-1">Light padrão</span><span className="rounded-full border border-white/25 px-3 py-1">Dark equivalente</span><span className="rounded-full border border-white/25 px-3 py-1">Mouse + touch</span></p></footer>
    </div>
  </div>;
}
